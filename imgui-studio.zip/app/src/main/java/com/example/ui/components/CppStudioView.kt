package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ImGuiThemeData
import com.example.viewmodel.ImGuiViewModel

@Composable
fun CppStudioView(
    viewModel: ImGuiViewModel,
    modifier: Modifier = Modifier
) {
    val theme by viewModel.theme.collectAsState()
    val activeFile by viewModel.activeStudioFile.collectAsState()
    val codeContent = viewModel.getCppCodeForCurrentFile()

    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }

    val files = listOf("main.cpp", "Menu.h", "Menu.cpp", "ESP.cpp", "Hooks.cpp", "Memory.h")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF090B10))
            .testTag("cpp_studio_view")
    ) {
        // Top Toolbar
        Surface(
            color = Color(0xFF10131C),
            border = BorderStroke(1.dp, Color(0xFF1E2333))
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left: File Title & Badge
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = null,
                            tint = Color(0xFF00F0FF),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "C++ Source Studio: $activeFile",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Right: Action Buttons
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { isSearchActive = !isSearchActive },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = if (isSearchActive) Color(0xFF00F0FF) else Color(0xFF94A3B8),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Button(
                            onClick = { viewModel.copyCodeToClipboard(codeContent, activeFile) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = theme.buttonBg,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_copy_cpp_code")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Copy $activeFile",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // File Tabs Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    files.forEach { file ->
                        val isSelected = file == activeFile
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) Color(0xFF1C2235) else Color.Transparent)
                                .border(
                                    1.dp,
                                    if (isSelected) Color(0xFF00F0FF) else Color(0x33475569),
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable { viewModel.setActiveStudioFile(file) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("file_tab_$file")
                        ) {
                            Text(
                                text = file,
                                color = if (isSelected) Color(0xFF00F0FF) else Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                }
            }
        }

        // Search Bar (if toggled)
        if (isSearchActive) {
            TextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Filter code lines...", color = Color(0xFF64748B), fontSize = 13.sp) },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF131724),
                    unfocusedContainerColor = Color(0xFF131724),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = Color(0xFF00F0FF)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            )
        }

        // Code Editor Body with Line Numbers and Syntax Highlighting
        val lines = remember(codeContent, searchQuery) {
            val raw = codeContent.lines()
            if (searchQuery.isBlank()) raw
            else raw.filter { it.contains(searchQuery, ignoreCase = true) }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0D0F17))
                .border(1.dp, Color(0xFF1F2438), RoundedCornerShape(8.dp))
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 6.dp)
            ) {
                itemsIndexed(lines) { index, line ->
                    val isMatch = searchQuery.isNotBlank() && line.contains(searchQuery, ignoreCase = true)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (isMatch) Color(0x3300F0FF) else Color.Transparent)
                            .padding(horizontal = 8.dp, vertical = 1.dp)
                    ) {
                        // Line Number
                        Text(
                            text = String.format("%3d", index + 1),
                            color = Color(0xFF475569),
                            fontSize = 11.5.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.width(36.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        // Syntax Highlighted Code
                        Text(
                            text = highlightCppSyntax(line),
                            fontSize = 11.5.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// High-Speed C++ Syntax Highlighter
// ----------------------------------------------------------------------------
private fun highlightCppSyntax(codeLine: String) = buildAnnotatedString {
    val trimmed = codeLine.trimStart()

    // Comments
    if (trimmed.startsWith("//") || trimmed.startsWith("/*") || trimmed.startsWith("*")) {
        withStyle(SpanStyle(color = Color(0xFF6B7280), fontWeight = FontWeight.Normal)) {
            append(codeLine)
        }
        return@buildAnnotatedString
    }

    // Preprocessor directives (#include, #define, #pragma)
    if (trimmed.startsWith("#")) {
        withStyle(SpanStyle(color = Color(0xFFFFB800), fontWeight = FontWeight.Bold)) {
            append(codeLine)
        }
        return@buildAnnotatedString
    }

    // Token Parser
    val keywords = setOf(
        "void", "bool", "int", "float", "double", "char", "auto",
        "struct", "class", "namespace", "return", "if", "else",
        "for", "while", "static", "const", "extern", "nullptr",
        "true", "false", "sizeof", "new", "delete", "typedef"
    )
    val imguiTypes = setOf(
        "ImVec2", "ImVec4", "ImU32", "ImGuiIO", "ImGuiStyle",
        "ImDrawList", "ImFontConfig", "EGLDisplay", "EGLSurface", "EGLBoolean"
    )

    var i = 0
    while (i < codeLine.length) {
        val c = codeLine[i]

        // Strings in quotes
        if (c == '"') {
            val nextQuote = codeLine.indexOf('"', i + 1)
            if (nextQuote != -1) {
                val str = codeLine.substring(i, nextQuote + 1)
                withStyle(SpanStyle(color = Color(0xFF34D399))) {
                    append(str)
                }
                i = nextQuote + 1
                continue
            }
        }

        // Identifiers
        if (c.isLetter() || c == '_') {
            var j = i
            while (j < codeLine.length && (codeLine[j].isLetterOrDigit() || codeLine[j] == '_')) {
                j++
            }
            val word = codeLine.substring(i, j)
            when {
                word in keywords -> withStyle(SpanStyle(color = Color(0xFF818CF8), fontWeight = FontWeight.Bold)) { append(word) }
                word in imguiTypes -> withStyle(SpanStyle(color = Color(0xFF00F0FF), fontWeight = FontWeight.SemiBold)) { append(word) }
                word.startsWith("ImGui") -> withStyle(SpanStyle(color = Color(0xFFA78BFA))) { append(word) }
                else -> withStyle(SpanStyle(color = Color(0xFFE2E8F0))) { append(word) }
            }
            i = j
            continue
        }

        // Numbers
        if (c.isDigit()) {
            var j = i
            while (j < codeLine.length && (codeLine[j].isDigit() || codeLine[j] == '.' || codeLine[j] == 'f' || codeLine[j] == 'x' || codeLine[j].isLetter())) {
                j++
            }
            val num = codeLine.substring(i, j)
            withStyle(SpanStyle(color = Color(0xFFFF70A6))) { append(num) }
            i = j
            continue
        }

        // Symbols and Operators
        withStyle(SpanStyle(color = Color(0xFF94A3B8))) {
            append(c)
        }
        i++
    }
}
