package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ImGuiThemeData
import kotlin.math.roundToInt

@Composable
fun FloatingBubble(
    isMenuOpen: Boolean,
    onToggleMenu: () -> Unit,
    theme: ImGuiThemeData,
    modifier: Modifier = Modifier
) {
    var bubbleOffset by remember { mutableStateOf(Offset(24f, 220f)) }

    Box(
        modifier = modifier
            .offset { IntOffset(bubbleOffset.x.roundToInt(), bubbleOffset.y.roundToInt()) }
            .size(54.dp)
            .shadow(12.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(theme.headerBg, theme.buttonBg, Color(0xFF0F111A))
                )
            )
            .border(2.dp, theme.accentGlow, CircleShape)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    bubbleOffset = Offset(
                        (bubbleOffset.x + dragAmount.x).coerceIn(0f, 800f),
                        (bubbleOffset.y + dragAmount.y).coerceIn(100f, 1600f)
                    )
                }
            }
            .clickable { onToggleMenu() }
            .testTag("imgui_floating_bubble"),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.FlashOn,
                contentDescription = "Toggle ImGui Menu",
                tint = if (isMenuOpen) Color(0xFF00F0FF) else Color.White,
                modifier = Modifier.size(24.dp)
            )
            Text(
                text = "IMGUI",
                color = Color.White,
                fontSize = 8.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.5.sp
            )
        }
    }
}
