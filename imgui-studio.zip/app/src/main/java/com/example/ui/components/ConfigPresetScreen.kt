package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CppGenerator
import com.example.viewmodel.ImGuiViewModel

@Composable
fun ConfigPresetScreen(
    viewModel: ImGuiViewModel,
    modifier: Modifier = Modifier
) {
    val theme by viewModel.theme.collectAsState()
    val esp by viewModel.esp.collectAsState()
    val aimbot by viewModel.aimbot.collectAsState()
    val memory by viewModel.memory.collectAsState()

    val presets = listOf(
        PresetCardData(
            title = "SkyMods VIP Signature",
            subtitle = "Optimal balance for Ranked & Tournament matches",
            badge = "RECOMMENDED",
            badgeColor = Color(0xFF00F0FF),
            description = "Corner ESP Boxes, Head Circles, Touch Simulation Smooth Aimbot, Unlimited Ammo, Anti-Ban Protection."
        ),
        PresetCardData(
            title = "Legit Safe",
            subtitle = "Ultra covert mode for strict anti-cheat environments",
            badge = "100% SAFE",
            badgeColor = Color(0xFF00FF66),
            description = "Subtle Corner ESP, 45° Small FOV, High Smoothness (12.0f), No Memory Hacks, Stream Proof."
        ),
        PresetCardData(
            title = "Full HvH / Rage",
            subtitle = "Unrestricted maximum destruction for custom rooms",
            badge = "MAX POWER",
            badgeColor = Color(0xFFFF2A54),
            description = "3D Wireframe Boxes, Silent Bullet Aim 180°, God Mode, Speed Hack 2.5x, Instant Triggerbot."
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0C13))
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
            .testTag("config_preset_screen")
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Bookmark,
                contentDescription = null,
                tint = Color(0xFF00F0FF),
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Config & Profile Manager",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "One-click load & instant C++ struct synchronization",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )
            }
        }

        // Preset Cards
        presets.forEach { p ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF121522)),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF222B42)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = p.title,
                            color = Color.White,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            color = p.badgeColor.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, p.badgeColor.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = p.badge,
                                color = p.badgeColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = p.subtitle,
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 2.dp, bottom = 6.dp)
                    )
                    Text(
                        text = p.description,
                        color = Color(0xFFCBD5E1),
                        fontSize = 11.5.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { viewModel.applyPresetConfig(p.title) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = theme.buttonBg,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().height(38.dp)
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Load ${p.title}", fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // C++ Struct Export Box
        ImGuiSectionHeader(title = "C++ Config Struct Export", theme = theme)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F121C)),
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1F263B)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "// Menu::Config Struct in Menu.h",
                    color = Color(0xFF64748B),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "struct Config {\n  bool esp_enabled = ${esp.enabled};\n  int esp_box_type = ${esp.boxType.ordinal};\n  bool aim_enabled = ${aimbot.enabled};\n  float aim_smooth = ${aimbot.smooth}f;\n  bool mem_antiban = ${memory.antiBanActive};\n};",
                    color = Color(0xFF00F0FF),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
                Button(
                    onClick = {
                        val headerCode = CppGenerator.generateMenuH(theme, esp, aimbot, memory)
                        viewModel.copyCodeToClipboard(headerCode, "Menu.h Config")
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = theme.frameBg,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, theme.borderColor),
                    modifier = Modifier.fillMaxWidth().height(36.dp)
                ) {
                    Icon(imageVector = Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Copy Config Struct", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private data class PresetCardData(
    val title: String,
    val subtitle: String,
    val badge: String,
    val badgeColor: Color,
    val description: String
)
