package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ImGuiThemeData
import java.util.Locale

@Composable
fun ImGuiCheckbox(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    theme: ImGuiThemeData,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onCheckedChange(!checked) }
            .padding(vertical = 4.dp, horizontal = 2.dp)
            .testTag("imgui_checkbox_${label.lowercase().replace(" ", "_")}")
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(20.dp)
                .clip(RoundedCornerShape(theme.frameRounding.dp))
                .background(if (checked) theme.buttonBg else theme.frameBg)
                .border(
                    width = 1.dp,
                    color = if (checked) theme.accentGlow else theme.borderColor.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(theme.frameRounding.dp)
                )
        ) {
            if (checked) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = theme.checkMarkColor,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = label,
            color = if (checked) theme.textPrimary else theme.textSecondary,
            fontSize = 13.sp,
            fontWeight = if (checked) FontWeight.SemiBold else FontWeight.Normal,
            fontFamily = FontFamily.SansSerif
        )
    }
}

@Composable
fun ImGuiSlider(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    theme: ImGuiThemeData,
    valueFormat: String = "%.1f",
    unit: String = "",
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp, horizontal = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                color = theme.textSecondary,
                fontSize = 12.sp,
                fontFamily = FontFamily.SansSerif
            )
            Text(
                text = String.format(Locale.US, "$valueFormat $unit", value),
                color = theme.accentGlow,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = theme.sliderGrabColor,
                activeTrackColor = theme.buttonBg,
                inactiveTrackColor = theme.frameBg
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(32.dp)
                .testTag("imgui_slider_${label.lowercase().replace(" ", "_")}")
        )
    }
}

@Composable
fun <T> ImGuiCombo(
    label: String,
    items: List<T>,
    selectedItem: T,
    onItemSelected: (T) -> Unit,
    itemLabel: (T) -> String,
    theme: ImGuiThemeData,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp, horizontal = 2.dp)
    ) {
        Text(
            text = label,
            color = theme.textSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(theme.frameRounding.dp))
                    .background(theme.frameBg)
                    .border(1.dp, theme.borderColor.copy(alpha = 0.6f), RoundedCornerShape(theme.frameRounding.dp))
                    .clickable { expanded = true }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
                    .testTag("imgui_combo_${label.lowercase().replace(" ", "_")}")
            ) {
                Text(
                    text = itemLabel(selectedItem),
                    color = theme.textPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = null,
                    tint = theme.accentGlow,
                    modifier = Modifier.size(18.dp)
                )
            }

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier
                    .background(theme.childBg)
                    .border(1.dp, theme.borderColor, RoundedCornerShape(8.dp))
            ) {
                items.forEach { item ->
                    val isSelected = item == selectedItem
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = itemLabel(item),
                                color = if (isSelected) theme.accentGlow else theme.textPrimary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        },
                        onClick = {
                            onItemSelected(item)
                            expanded = false
                        },
                        modifier = Modifier.background(
                            if (isSelected) theme.buttonBg.copy(alpha = 0.35f) else Color.Transparent
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun ImGuiColorField(
    label: String,
    color: Color,
    onColorChange: (Color) -> Unit,
    theme: ImGuiThemeData,
    modifier: Modifier = Modifier
) {
    var showDialog by remember { mutableStateOf(false) }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = modifier
            .fillMaxWidth()
            .clickable { showDialog = true }
            .padding(vertical = 4.dp, horizontal = 2.dp)
            .testTag("imgui_color_${label.lowercase().replace(" ", "_")}")
    ) {
        Text(
            text = label,
            color = theme.textSecondary,
            fontSize = 12.sp
        )
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp, 16.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color)
                    .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
            )
            Spacer(modifier = Modifier.width(6.dp))
            val hex = String.format(Locale.US, "#%02X%02X%02X", (color.red * 255).toInt(), (color.green * 255).toInt(), (color.blue * 255).toInt())
            Text(
                text = hex,
                color = theme.textPrimary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }

    if (showDialog) {
        val quickColors = listOf(
            Color(0xFF00F0FF), Color(0xFFFF007F), Color(0xFF00FF66),
            Color(0xFFFF2A54), Color(0xFF8B5CF6), Color(0xFFFFB800),
            Color(0xFFFFFFFF), Color(0xFF38BDF8), Color(0xFFE11D48),
            Color(0xFF10B981), Color(0xFFA855F7), Color(0xFFF97316)
        )
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = {
                Text(
                    text = "Pick Color: $label",
                    color = theme.textPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = "Quick Palette:",
                        color = theme.textSecondary,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        quickColors.take(6).forEach { c ->
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(c)
                                    .border(
                                        2.dp,
                                        if (c == color) Color.White else Color.Transparent,
                                        CircleShape
                                    )
                                    .clickable {
                                        onColorChange(c)
                                        showDialog = false
                                    }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        quickColors.drop(6).take(6).forEach { c ->
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(c)
                                    .border(
                                        2.dp,
                                        if (c == color) Color.White else Color.Transparent,
                                        CircleShape
                                    )
                                    .clickable {
                                        onColorChange(c)
                                        showDialog = false
                                    }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Close", color = theme.accentGlow)
                }
            },
            containerColor = theme.childBg
        )
    }
}

@Composable
fun ImGuiButton(
    text: String,
    onClick: () -> Unit,
    theme: ImGuiThemeData,
    modifier: Modifier = Modifier,
    isPrimary: Boolean = true
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isPrimary) theme.buttonBg else theme.frameBg,
            contentColor = theme.textPrimary
        ),
        shape = RoundedCornerShape(theme.frameRounding.dp),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
        modifier = modifier
            .border(
                1.dp,
                if (isPrimary) theme.accentGlow.copy(alpha = 0.8f) else theme.borderColor.copy(alpha = 0.5f),
                RoundedCornerShape(theme.frameRounding.dp)
            )
            .testTag("imgui_btn_${text.lowercase().replace(" ", "_")}")
    ) {
        Text(
            text = text,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun ImGuiSectionHeader(
    title: String,
    theme: ImGuiThemeData,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(14.dp)
                    .background(theme.accentGlow, RoundedCornerShape(2.dp))
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title.uppercase(),
                color = theme.accentGlow,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(theme.borderColor.copy(alpha = 0.4f))
        )
    }
}
