package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import kotlin.math.*

@Composable
fun EspSandboxView(
    esp: EspSettings,
    aimbot: AimbotSettings,
    memory: MemoryModsSettings,
    theme: ImGuiThemeData,
    targets: List<DummyTarget>,
    lockedTargetId: Int?,
    fps: Float,
    ping: Int,
    onSpawnBot: () -> Unit,
    onDamageTarget: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF07090E))
            .testTag("esp_sandbox_view")
    ) {
        // Main Interactive Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(targets) {
                    detectTapGestures { tapOffset ->
                        // Find if tapped near any target
                        val hit = targets.find {
                            val dx = it.posX - tapOffset.x
                            val dy = it.posY - tapOffset.y
                            sqrt(dx * dx + dy * dy) < 80f
                        }
                        if (hit != null) {
                            onDamageTarget(hit.id)
                        }
                    }
                }
        ) {
            val width = size.width
            val height = size.height
            val centerX = width / 2f
            val centerY = height / 2f

            // 1. Draw 3D Perspective Ground Grid & Horizon
            drawPerspectiveBattleground(width, height)

            // 2. Draw Simulated Crosshair
            drawCrosshair(centerX, centerY, if (lockedTargetId != null) Color(0xFFFF0055) else Color(0x9900F0FF))

            // 3. Draw FOV Circle
            if (esp.enabled && esp.drawFovCircle) {
                drawCircle(
                    color = if (esp.rainbowFov) Color(0xFFFF007F) else esp.fovColor,
                    radius = esp.fovRadius,
                    center = Offset(centerX, centerY),
                    style = Stroke(width = esp.fovThickness)
                )
                if (lockedTargetId != null) {
                    drawCircle(
                        color = Color(0x33FF0055),
                        radius = esp.fovRadius,
                        center = Offset(centerX, centerY)
                    )
                }
            }

            // 4. Draw Targets & ESP Overlays
            targets.forEach { target ->
                val isLocked = (target.id == lockedTargetId)
                drawEnemyTargetWithEsp(
                    target = target,
                    esp = esp,
                    isLocked = isLocked,
                    screenCenter = Offset(centerX, centerY),
                    screenBottom = Offset(centerX, height),
                    screenTop = Offset(centerX, 0f),
                    textMeasurer = textMeasurer,
                    theme = theme
                )
            }

            // 5. Draw 2D Tactical Mini Radar
            if (esp.enabled && esp.drawRadar) {
                drawTacticalRadar(
                    radarX = esp.radarPosX,
                    radarY = esp.radarPosY,
                    radarScale = esp.radarScale,
                    targets = targets,
                    theme = theme
                )
            }
        }

        // Top Sandbox Status Bar HUD
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left HUD Info
            Surface(
                color = Color(0xCC0D111A),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Color(0xFF243048))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00FF66))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ESP Engine: ACTIVE",
                        color = Color(0xFF00FF66),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Targets: ${targets.size} (${targets.count { it.health > 0 }} Alive)",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Right HUD Controls
            Row {
                FilledTonalIconButton(
                    onClick = onSpawnBot,
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = theme.buttonBg.copy(alpha = 0.8f),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.size(36.dp).testTag("sandbox_spawn_bot")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Spawn Dummy Bot", modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// Canvas Drawing Helper Functions
// ----------------------------------------------------------------------------

private fun DrawScope.drawPerspectiveBattleground(w: Float, h: Float) {
    val horizonY = h * 0.38f

    // Sky gradient
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color(0xFF05060A), Color(0xFF0B101E)),
            startY = 0f,
            endY = horizonY
        ),
        topLeft = Offset(0f, 0f),
        size = Size(w, horizonY)
    )

    // Horizon glowing line
    drawLine(
        color = Color(0x3300F0FF),
        start = Offset(0f, horizonY),
        end = Offset(w, horizonY),
        strokeWidth = 1.5f
    )

    // Ground gradient
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color(0xFF0C101A), Color(0xFF06080E)),
            startY = horizonY,
            endY = h
        ),
        topLeft = Offset(0f, horizonY),
        size = Size(w, h - horizonY)
    )

    // Perspective Grid Lines
    val vanishingPoint = Offset(w * 0.5f, horizonY)
    val numLines = 14
    for (i in 0..numLines) {
        val bottomX = (w / numLines) * i
        drawLine(
            color = Color(0x1838BDF8),
            start = vanishingPoint,
            end = Offset(bottomX, h),
            strokeWidth = 1f
        )
    }

    // Horizontal Depth Grid Lines
    var currY = horizonY + 20f
    var step = 15f
    while (currY < h) {
        drawLine(
            color = Color(0x1438BDF8),
            start = Offset(0f, currY),
            end = Offset(w, currY),
            strokeWidth = 1f
        )
        step *= 1.35f
        currY += step
    }
}

private fun DrawScope.drawCrosshair(cx: Float, cy: Float, color: Color) {
    val size = 12f
    val gap = 4f
    val thickness = 1.8f

    // Top
    drawLine(color, Offset(cx, cy - gap), Offset(cx, cy - gap - size), thickness)
    // Bottom
    drawLine(color, Offset(cx, cy + gap), Offset(cx, cy + gap + size), thickness)
    // Left
    drawLine(color, Offset(cx - gap, cy), Offset(cx - gap - size, cy), thickness)
    // Right
    drawLine(color, Offset(cx + gap, cy), Offset(cx + gap + size, cy), thickness)
    // Center dot
    drawCircle(color, 2f, Offset(cx, cy))
}

private fun DrawScope.drawEnemyTargetWithEsp(
    target: DummyTarget,
    esp: EspSettings,
    isLocked: Boolean,
    screenCenter: Offset,
    screenBottom: Offset,
    screenTop: Offset,
    textMeasurer: androidx.compose.ui.text.TextMeasurer,
    theme: ImGuiThemeData
) {
    val x = target.posX
    val y = target.posY
    // Perspective scale based on distance
    val scale = (100f / (target.distanceMeters + 20f)).coerceIn(0.6f, 2.2f)
    val bodyW = 34f * scale
    val bodyH = 80f * scale
    val headRadius = 8f * scale

    val topY = y - bodyH
    val bottomY = y
    val leftX = x - bodyW / 2f
    val rightX = x + bodyW / 2f
    val headCenter = Offset(x, topY - headRadius)

    val primaryColor = when {
        isLocked -> Color(0xFFFF0055)
        target.isKnocked -> Color(0xFFFF9900)
        target.isBot -> Color(0xFF94A3B8)
        else -> esp.boxColor
    }

    // 1. Chams Shader Effect (Silhouette / Glow)
    if (esp.chamsShader != ChamsShader.NONE) {
        val chamsColor = when (esp.chamsShader) {
            ChamsShader.GLOW_OUTLINE -> esp.chamsColor.copy(alpha = 0.45f)
            ChamsShader.WIREFRAME -> esp.chamsColor.copy(alpha = 0.8f)
            ChamsShader.SOLID_COLOR -> esp.chamsColor.copy(alpha = 0.6f)
            ChamsShader.PULSE_HOLOGRAM -> Color(0xFF00F0FF).copy(alpha = 0.5f)
            else -> Color.Transparent
        }
        drawCircle(chamsColor, headRadius * 1.3f, headCenter)
        drawRoundRect(
            color = chamsColor,
            topLeft = Offset(leftX - 4f, topY - 4f),
            size = Size(bodyW + 8f, bodyH + 8f),
            cornerRadius = CornerRadius(6f, 6f)
        )
    }

    // Draw Simulated Dummy Character Model (Torso, limbs)
    drawDummyCharacterBody(x, y, topY, headRadius, bodyW, bodyH, isLocked, target.isKnocked)

    if (!esp.enabled) return

    // 2. Snaplines
    if (esp.linePos != LinePos.NONE) {
        val startLine = when (esp.linePos) {
            LinePos.TOP -> screenTop
            LinePos.CENTER -> screenCenter
            LinePos.BOTTOM -> screenBottom
            else -> screenBottom
        }
        val targetPoint = if (esp.linePos == LinePos.TOP) headCenter else Offset(x, bottomY)
        drawLine(
            color = if (isLocked) Color(0xFFFF0055) else esp.lineColor,
            start = startLine,
            end = targetPoint,
            strokeWidth = if (isLocked) 2.5f else 1.2f
        )
    }

    // 3. ESP Boxes (2D, Corner, 3D)
    when (esp.boxType) {
        BoxType.BOX_2D -> {
            drawRect(
                color = primaryColor,
                topLeft = Offset(leftX, topY),
                size = Size(bodyW, bodyH),
                style = Stroke(width = if (isLocked) 2.5f else 1.5f)
            )
            // Inner shadow
            drawRect(
                color = primaryColor.copy(alpha = 0.12f),
                topLeft = Offset(leftX, topY),
                size = Size(bodyW, bodyH)
            )
        }
        BoxType.BOX_CORNER -> {
            val cornerW = bodyW * 0.28f
            val cornerH = bodyH * 0.22f
            val thick = if (isLocked) 2.8f else 1.8f

            // Top-Left
            drawLine(primaryColor, Offset(leftX, topY), Offset(leftX + cornerW, topY), thick)
            drawLine(primaryColor, Offset(leftX, topY), Offset(leftX, topY + cornerH), thick)
            // Top-Right
            drawLine(primaryColor, Offset(rightX, topY), Offset(rightX - cornerW, topY), thick)
            drawLine(primaryColor, Offset(rightX, topY), Offset(rightX, topY + cornerH), thick)
            // Bottom-Left
            drawLine(primaryColor, Offset(leftX, bottomY), Offset(leftX + cornerW, bottomY), thick)
            drawLine(primaryColor, Offset(leftX, bottomY), Offset(leftX, bottomY - cornerH), thick)
            // Bottom-Right
            drawLine(primaryColor, Offset(rightX, bottomY), Offset(rightX - cornerW, bottomY), thick)
            drawLine(primaryColor, Offset(rightX, bottomY), Offset(rightX, bottomY - cornerH), thick)
        }
        BoxType.BOX_3D -> {
            val depth = 16f * scale
            val thick = 1.5f
            // Front face
            drawRect(primaryColor, Offset(leftX, topY), Size(bodyW, bodyH), style = Stroke(thick))
            // Back face
            drawRect(primaryColor.copy(alpha = 0.5f), Offset(leftX + depth, topY - depth), Size(bodyW, bodyH), style = Stroke(thick))
            // Connecting corners
            drawLine(primaryColor, Offset(leftX, topY), Offset(leftX + depth, topY - depth), thick)
            drawLine(primaryColor, Offset(rightX, topY), Offset(rightX + depth, topY - depth), thick)
            drawLine(primaryColor, Offset(leftX, bottomY), Offset(leftX + depth, bottomY - depth), thick)
            drawLine(primaryColor, Offset(rightX, bottomY), Offset(rightX + depth, bottomY - depth), thick)
        }
        BoxType.NONE -> {}
    }

    // 4. Head Dot & Circle
    if (esp.drawHeadCircle) {
        drawCircle(
            color = if (isLocked) Color(0xFFFF0055) else esp.headColor,
            radius = headRadius,
            center = headCenter,
            style = Stroke(width = 1.8f)
        )
        drawCircle(
            color = if (isLocked) Color(0xFFFF0055) else esp.headColor,
            radius = 2.5f,
            center = headCenter
        )
    }

    // 5. Skeleton ESP
    if (esp.drawSkeleton && !target.isKnocked) {
        val skelColor = esp.skeletonColor
        val neckY = topY + 6f * scale
        val chestY = topY + 22f * scale
        val pelvisY = topY + 44f * scale
        val leftKneeY = topY + 62f * scale
        val rightKneeY = topY + 62f * scale

        // Spine
        drawLine(skelColor, Offset(x, topY), Offset(x, pelvisY), 1.5f)
        // Shoulders & Arms
        drawLine(skelColor, Offset(leftX + 2f, chestY + 10f), Offset(x, neckY), 1.5f)
        drawLine(skelColor, Offset(rightX - 2f, chestY + 10f), Offset(x, neckY), 1.5f)
        // Legs
        drawLine(skelColor, Offset(x, pelvisY), Offset(leftX + 4f, leftKneeY), 1.5f)
        drawLine(skelColor, Offset(leftX + 4f, leftKneeY), Offset(leftX + 2f, bottomY), 1.5f)
        drawLine(skelColor, Offset(x, pelvisY), Offset(rightX - 4f, rightKneeY), 1.5f)
        drawLine(skelColor, Offset(rightX - 4f, rightKneeY), Offset(rightX - 2f, bottomY), 1.5f)
    }

    // 6. Health Bar
    if (esp.drawHealthBar) {
        val barW = 3.5f
        val barX = leftX - barW - 4f
        val hpPercent = (target.health / 100f).coerceIn(0f, 1f)
        val hpBarH = bodyH * hpPercent

        // Background
        drawRect(Color(0x99000000), Offset(barX, topY), Size(barW, bodyH))
        // Health fill
        val hpColor = when {
            hpPercent > 0.6f -> Color(0xFF00FF66)
            hpPercent > 0.25f -> Color(0xFFFFB800)
            else -> Color(0xFFFF2A54)
        }
        drawRect(
            color = hpColor,
            topLeft = Offset(barX, topY + (bodyH - hpBarH)),
            size = Size(barW, hpBarH)
        )
    }

    // 7. Armor Bar
    if (esp.drawArmorBar && target.armor > 0f) {
        val barW = 3.5f
        val barX = rightX + 4f
        val armorPercent = (target.armor / 100f).coerceIn(0f, 1f)
        val armorBarH = bodyH * armorPercent

        drawRect(Color(0x99000000), Offset(barX, topY), Size(barW, bodyH))
        drawRect(
            color = Color(0xFF00F0FF),
            topLeft = Offset(barX, topY + (bodyH - armorBarH)),
            size = Size(barW, armorBarH)
        )
    }

    // 8. Player Info Text Tags (Name, Distance, Weapon)
    if (esp.drawPlayerName || esp.drawDistance) {
        val nameText = buildString {
            if (esp.drawPlayerName) append(target.name)
            if (esp.drawDistance) {
                if (isNotEmpty()) append(" ")
                append("[${target.distanceMeters.toInt()}m]")
            }
        }
        val textLayout = textMeasurer.measure(
            text = nameText,
            style = TextStyle(
                color = Color.White,
                fontSize = (9f * scale).coerceIn(8f, 12f).sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.SansSerif
            )
        )
        val textX = x - textLayout.size.width / 2f
        val textY = topY - headRadius * 2f - textLayout.size.height - 4f

        // Draw background pill
        drawRoundRect(
            color = Color(0xCC0B0E14),
            topLeft = Offset(textX - 4f, textY - 2f),
            size = Size(textLayout.size.width + 8f, textLayout.size.height + 4f),
            cornerRadius = CornerRadius(4f, 4f)
        )
        drawText(textLayout, topLeft = Offset(textX, textY))
    }

    // Weapon Tag Below
    if (esp.drawWeaponName && target.weapon.isNotEmpty()) {
        val weaponLayout = textMeasurer.measure(
            text = target.weapon,
            style = TextStyle(
                color = Color(0xFFFFB800),
                fontSize = (8.5f * scale).coerceIn(7.5f, 11f).sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace
            )
        )
        val wX = x - weaponLayout.size.width / 2f
        val wY = bottomY + 4f

        drawRoundRect(
            color = Color(0xCC0B0E14),
            topLeft = Offset(wX - 4f, wY - 1f),
            size = Size(weaponLayout.size.width + 8f, weaponLayout.size.height + 2f),
            cornerRadius = CornerRadius(3f, 3f)
        )
        drawText(weaponLayout, topLeft = Offset(wX, wY))
    }
}

private fun DrawScope.drawDummyCharacterBody(
    x: Float,
    y: Float,
    topY: Float,
    headRadius: Float,
    bodyW: Float,
    bodyH: Float,
    isLocked: Boolean,
    isKnocked: Boolean
) {
    val bodyColor = if (isKnocked) Color(0xFF553322) else Color(0xFF222838)
    val headCenter = Offset(x, topY - headRadius)

    // Head
    drawCircle(bodyColor, headRadius, headCenter)

    // Torso
    drawRoundRect(
        color = bodyColor,
        topLeft = Offset(x - bodyW * 0.4f, topY),
        size = Size(bodyW * 0.8f, bodyH * 0.5f),
        cornerRadius = CornerRadius(4f, 4f)
    )

    // Legs
    val legW = bodyW * 0.3f
    val legH = bodyH * 0.5f
    drawRect(bodyColor, Offset(x - bodyW * 0.38f, topY + bodyH * 0.5f), Size(legW, legH))
    drawRect(bodyColor, Offset(x + bodyW * 0.08f, topY + bodyH * 0.5f), Size(legW, legH))
}

private fun DrawScope.drawTacticalRadar(
    radarX: Float,
    radarY: Float,
    radarScale: Float,
    targets: List<DummyTarget>,
    theme: ImGuiThemeData
) {
    val radarSize = 130f * radarScale
    val rCenter = Offset(radarX + radarSize / 2f, radarY + radarSize / 2f)
    val rRadius = radarSize / 2f

    // Radar Dark Glass Background
    drawCircle(
        color = Color(0xEE0B0E17),
        radius = rRadius,
        center = rCenter
    )
    drawCircle(
        color = theme.borderColor.copy(alpha = 0.8f),
        radius = rRadius,
        center = rCenter,
        style = Stroke(width = 1.5f)
    )

    // Concentric Range Rings
    drawCircle(Color(0x2238BDF8), rRadius * 0.65f, rCenter, style = Stroke(1f))
    drawCircle(Color(0x1538BDF8), rRadius * 0.35f, rCenter, style = Stroke(1f))

    // Cross axes
    drawLine(Color(0x33FFFFFF), Offset(rCenter.x - rRadius, rCenter.y), Offset(rCenter.x + rRadius, rCenter.y), 1f)
    drawLine(Color(0x33FFFFFF), Offset(rCenter.x, rCenter.y - rRadius), Offset(rCenter.x, rCenter.y + rRadius), 1f)

    // Player indicator in radar center
    drawCircle(Color(0xFF00F0FF), 3.5f, rCenter)
    // Vision cone
    drawArc(
        color = Color(0x2200F0FF),
        startAngle = 240f,
        sweepAngle = 60f,
        useCenter = true,
        topLeft = Offset(rCenter.x - rRadius, rCenter.y - rRadius),
        size = Size(radarSize, radarSize)
    )

    // Enemy Blips on Radar
    targets.forEach { t ->
        val relX = (t.posX - 500f) * 0.12f * radarScale
        val relY = (t.posY - 550f) * 0.12f * radarScale
        val blipPos = Offset(
            (rCenter.x + relX).coerceIn(rCenter.x - rRadius + 6f, rCenter.x + rRadius - 6f),
            (rCenter.y + relY).coerceIn(rCenter.y - rRadius + 6f, rCenter.y + rRadius - 6f)
        )
        val blipColor = if (t.isKnocked) Color(0xFFFF9900) else Color(0xFFFF0055)
        drawCircle(blipColor, 3f, blipPos)
    }
}
