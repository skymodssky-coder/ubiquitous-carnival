package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyberpunk / Gaming High-Tech Palette
val CyberBackground = Color(0xFF0B0D14)
val CyberSurface = Color(0xFF121522)
val CyberSurfaceVariant = Color(0xFF191E30)
val CyberBorder = Color(0xFF2E3856)

val CyberCyan = Color(0xFF00F0FF)
val CyberPurple = Color(0xFF8B5CF6)
val CyberNeonMagenta = Color(0xFFFF007F)
val CyberCrimson = Color(0xFFFF2A54)
val CyberGreen = Color(0xFF00FF66)
val CyberGold = Color(0xFFFFB800)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// ImGui Custom Accent Colors
val ImGuiViolet = Color(0xFF7C3AED)
val ImGuiVioletDark = Color(0xFF5B21B6)
val ImGuiVioletLight = Color(0xFFA78BFA)
val ImGuiWindowDark = Color(0xEB0F101A)
val ImGuiFrameBg = Color(0xFF1B1E2E)
