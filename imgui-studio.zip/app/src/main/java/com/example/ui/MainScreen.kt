package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.viewmodel.ImGuiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: ImGuiViewModel,
    modifier: Modifier = Modifier
) {
    val theme by viewModel.theme.collectAsState()
    val esp by viewModel.esp.collectAsState()
    val aimbot by viewModel.aimbot.collectAsState()
    val memory by viewModel.memory.collectAsState()
    val isMenuOpen by viewModel.isMenuOpen.collectAsState()
    val targets by viewModel.targets.collectAsState()
    val lockedTargetId by viewModel.lockedTargetId.collectAsState()
    val fps by viewModel.fps.collectAsState()
    val ping by viewModel.ping.collectAsState()

    var activeNavMode by remember { mutableStateOf(0) } // 0: ESP Sandbox & Floating Menu, 1: C++ Code Studio, 2: Theme Architect, 3: Configs

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00FF66))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "ImGui Studio & C++ Architect",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Android GLES3 Mod Menu & Shader Engine",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp
                            )
                        }
                    }
                },
                actions = {
                    // Toggle ImGui Menu Button in Top Bar
                    IconButton(
                        onClick = { viewModel.toggleMenu() },
                        modifier = Modifier.testTag("topbar_btn_toggle_menu")
                    ) {
                        Icon(
                            imageVector = if (isMenuOpen) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle Menu Visibility",
                            tint = if (isMenuOpen) Color(0xFF00F0FF) else Color(0xFF64748B)
                        )
                    }

                    // Copy active C++ code button
                    IconButton(
                        onClick = {
                            val code = viewModel.getCppCodeForCurrentFile()
                            viewModel.copyCodeToClipboard(code, "C++ Source Code")
                        },
                        modifier = Modifier.testTag("topbar_btn_copy_code")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy C++ Code",
                            tint = Color(0xFF00F0FF)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0D0F17)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0D0F17),
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = activeNavMode == 0,
                    onClick = { activeNavMode = 0 },
                    icon = { Icon(Icons.Default.SportsEsports, contentDescription = "ESP Sandbox") },
                    label = { Text("ESP Sandbox", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF00F0FF),
                        selectedTextColor = Color(0xFF00F0FF),
                        indicatorColor = Color(0xFF1E2538),
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("nav_item_sandbox")
                )
                NavigationBarItem(
                    selected = activeNavMode == 1,
                    onClick = { activeNavMode = 1 },
                    icon = { Icon(Icons.Default.Code, contentDescription = "C++ Studio") },
                    label = { Text("C++ Studio", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF00F0FF),
                        selectedTextColor = Color(0xFF00F0FF),
                        indicatorColor = Color(0xFF1E2538),
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("nav_item_cpp")
                )
                NavigationBarItem(
                    selected = activeNavMode == 2,
                    onClick = { activeNavMode = 2 },
                    icon = { Icon(Icons.Default.Palette, contentDescription = "Theme") },
                    label = { Text("Theme UI", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF00F0FF),
                        selectedTextColor = Color(0xFF00F0FF),
                        indicatorColor = Color(0xFF1E2538),
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("nav_item_theme")
                )
                NavigationBarItem(
                    selected = activeNavMode == 3,
                    onClick = { activeNavMode = 3 },
                    icon = { Icon(Icons.Default.Tune, contentDescription = "Configs") },
                    label = { Text("Presets", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF00F0FF),
                        selectedTextColor = Color(0xFF00F0FF),
                        indicatorColor = Color(0xFF1E2538),
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("nav_item_configs")
                )
            }
        },
        containerColor = Color(0xFF08090F),
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Screen Mode
            when (activeNavMode) {
                0 -> {
                    // Sandbox Game Canvas
                    EspSandboxView(
                        esp = esp,
                        aimbot = aimbot,
                        memory = memory,
                        theme = theme,
                        targets = targets,
                        lockedTargetId = lockedTargetId,
                        fps = fps,
                        ping = ping,
                        onSpawnBot = { viewModel.spawnDummyBot() },
                        onDamageTarget = { viewModel.damageTarget(it) },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Floating ImGui Menu Window (Draggable & Collapsible)
                    AnimatedVisibility(
                        visible = isMenuOpen,
                        enter = fadeIn() + slideInVertically { it / 2 },
                        exit = fadeOut() + slideOutVertically { it / 2 }
                    ) {
                        ImGuiWindow(
                            viewModel = viewModel,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Floating Bubble Badge (always visible to toggle menu)
                    FloatingBubble(
                        isMenuOpen = isMenuOpen,
                        onToggleMenu = { viewModel.toggleMenu() },
                        theme = theme
                    )
                }
                1 -> {
                    CppStudioView(
                        viewModel = viewModel,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                2 -> {
                    ThemeDesignerScreen(
                        viewModel = viewModel,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                3 -> {
                    ConfigPresetScreen(
                        viewModel = viewModel,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}
