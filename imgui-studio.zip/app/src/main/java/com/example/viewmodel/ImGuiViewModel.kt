package com.example.viewmodel

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class ImGuiViewModel(application: Application) : AndroidViewModel(application) {

    private val _theme = MutableStateFlow(ImGuiThemeData())
    val theme: StateFlow<ImGuiThemeData> = _theme.asStateFlow()

    private val _esp = MutableStateFlow(EspSettings())
    val esp: StateFlow<EspSettings> = _esp.asStateFlow()

    private val _aimbot = MutableStateFlow(AimbotSettings())
    val aimbot: StateFlow<AimbotSettings> = _aimbot.asStateFlow()

    private val _memory = MutableStateFlow(MemoryModsSettings())
    val memory: StateFlow<MemoryModsSettings> = _memory.asStateFlow()

    private val _isMenuOpen = MutableStateFlow(true)
    val isMenuOpen: StateFlow<Boolean> = _isMenuOpen.asStateFlow()

    private val _isMenuCollapsed = MutableStateFlow(false)
    val isMenuCollapsed: StateFlow<Boolean> = _isMenuCollapsed.asStateFlow()

    private val _windowOffset = MutableStateFlow(Offset(60f, 120f))
    val windowOffset: StateFlow<Offset> = _windowOffset.asStateFlow()

    private val _activeTab = MutableStateFlow(0) // 0: ESP, 1: Aimbot, 2: Memory, 3: Theme, 4: C++, 5: Configs
    val activeTab: StateFlow<Int> = _activeTab.asStateFlow()

    private val _activeStudioFile = MutableStateFlow("main.cpp")
    val activeStudioFile: StateFlow<String> = _activeStudioFile.asStateFlow()

    private val _fps = MutableStateFlow(60.0f)
    val fps: StateFlow<Float> = _fps.asStateFlow()

    private val _ping = MutableStateFlow(18)
    val ping: StateFlow<Int> = _ping.asStateFlow()

    private val _targets = MutableStateFlow<List<DummyTarget>>(emptyList())
    val targets: StateFlow<List<DummyTarget>> = _targets.asStateFlow()

    private val _lockedTargetId = MutableStateFlow<Int?>(null)
    val lockedTargetId: StateFlow<Int?> = _lockedTargetId.asStateFlow()

    private val _isFloatingOverlayMode = MutableStateFlow(false)
    val isFloatingOverlayMode: StateFlow<Boolean> = _isFloatingOverlayMode.asStateFlow()

    private val _appMode = MutableStateFlow(0) // 0: Live Game ESP Sandbox, 1: C++ IDE Studio, 2: Theme Architect, 3: Floating Overlay

    init {
        initDummyTargets()
        startSimulationLoop()
    }

    private fun initDummyTargets() {
        val initialList = listOf(
            DummyTarget(
                id = 1,
                posX = 320f,
                posY = 480f,
                distanceMeters = 24.5f,
                health = 100f,
                armor = 85f,
                name = "xX_Slayer_Xx",
                weapon = "M416 [Max]",
                isKnocked = false,
                isBot = false,
                teamId = 2,
                velocityX = 0.8f,
                velocityY = 0.3f
            ),
            DummyTarget(
                id = 2,
                posX = 650f,
                posY = 530f,
                distanceMeters = 48.2f,
                health = 72f,
                armor = 50f,
                name = "Ghost_Recon",
                weapon = "AWM [Scope 8x]",
                isKnocked = false,
                isBot = false,
                teamId = 3,
                velocityX = -0.6f,
                velocityY = 0.5f
            ),
            DummyTarget(
                id = 3,
                posX = 210f,
                posY = 720f,
                distanceMeters = 12.0f,
                health = 25f,
                armor = 0f,
                name = "NoobBot_99",
                weapon = "AKM",
                isKnocked = true,
                isBot = true,
                teamId = 4,
                velocityX = 0.2f,
                velocityY = -0.2f
            ),
            DummyTarget(
                id = 4,
                posX = 820f,
                posY = 360f,
                distanceMeters = 78.4f,
                health = 90f,
                armor = 100f,
                name = "SkyWalker_Vip",
                weapon = "Kar98k",
                isKnocked = false,
                isBot = false,
                teamId = 5,
                velocityX = 0.5f,
                velocityY = -0.4f
            )
        )
        _targets.value = initialList
    }

    private fun startSimulationLoop() {
        viewModelScope.launch {
            var tick = 0L
            while (isActive) {
                tick++
                delay(16) // ~60 FPS

                // Update FPS & Ping slightly
                if (tick % 30 == 0L) {
                    _fps.value = 59.4f + Random.nextFloat() * 1.2f
                    _ping.value = 16 + Random.nextInt(6)
                }

                // Simulate target movement & physics
                _targets.update { currentList ->
                    currentList.map { target ->
                        var newX = target.posX + target.velocityX
                        var newY = target.posY + target.velocityY
                        var newVx = target.velocityX
                        var newVy = target.velocityY

                        // Screen bounds bounce
                        if (newX < 120f || newX > 920f) {
                            newVx = -newVx
                            newX = newX.coerceIn(120f, 920f)
                        }
                        if (newY < 240f || newY > 850f) {
                            newVy = -newVy
                            newY = newY.coerceIn(240f, 850f)
                        }

                        // Slight distance drift
                        val distDrift = sin(tick * 0.02f + target.id) * 0.05f
                        val newDist = (target.distanceMeters + distDrift).coerceIn(5f, 150f)

                        target.copy(
                            posX = newX,
                            posY = newY,
                            velocityX = newVx,
                            velocityY = newVy,
                            distanceMeters = newDist
                        )
                    }
                }

                // Aimbot target lock simulation
                if (_aimbot.value.enabled) {
                    val activeList = _targets.value.filter {
                        (!_aimbot.value.ignoreKnocked || !it.isKnocked) &&
                        (!_aimbot.value.ignoreBots || !it.isBot)
                    }
                    if (activeList.isNotEmpty()) {
                        // Find closest to screen center (simulated crosshair at 500, 550)
                        val crosshairX = 500f
                        val crosshairY = 550f
                        val best = activeList.minByOrNull {
                            val dx = it.posX - crosshairX
                            val dy = it.posY - crosshairY
                            sqrt(dx * dx + dy * dy)
                        }
                        _lockedTargetId.value = best?.id
                    } else {
                        _lockedTargetId.value = null
                    }
                } else {
                    _lockedTargetId.value = null
                }
            }
        }
    }

    fun toggleMenu() {
        _isMenuOpen.update { !it }
    }

    fun setMenuOpen(open: Boolean) {
        _isMenuOpen.value = open
    }

    fun toggleCollapse() {
        _isMenuCollapsed.update { !it }
    }

    fun updateWindowOffset(dragDelta: Offset) {
        _windowOffset.update {
            Offset(
                (it.x + dragDelta.x).coerceIn(0f, 600f),
                (it.y + dragDelta.y).coerceIn(0f, 1200f)
            )
        }
    }

    fun setActiveTab(index: Int) {
        _activeTab.value = index
    }

    fun setActiveStudioFile(fileName: String) {
        _activeStudioFile.value = fileName
    }

    fun updateEsp(update: (EspSettings) -> EspSettings) {
        _esp.update(update)
    }

    fun updateAimbot(update: (AimbotSettings) -> AimbotSettings) {
        _aimbot.update(update)
    }

    fun updateMemory(update: (MemoryModsSettings) -> MemoryModsSettings) {
        _memory.update(update)
    }

    fun updateTheme(update: (ImGuiThemeData) -> ImGuiThemeData) {
        _theme.update(update)
    }

    fun applyThemePreset(preset: ThemePreset) {
        val newTheme = when (preset) {
            ThemePreset.CYBERPUNK_VIOLET -> ImGuiThemeData(
                preset = preset,
                windowBg = Color(0xF012131C),
                childBg = Color(0xF0181A26),
                headerBg = Color(0xFF7C3AED),
                headerHovered = Color(0xFF9055FF),
                headerActive = Color(0xFF6D28D9),
                buttonBg = Color(0xFF6D28D9),
                buttonHovered = Color(0xFF7C3AED),
                buttonActive = Color(0xFF5B21B6),
                frameBg = Color(0xFF1E2130),
                frameBgHovered = Color(0xFF282C40),
                frameBgActive = Color(0xFF333852),
                borderColor = Color(0xFF8B5CF6),
                checkMarkColor = Color(0xFF00F0FF),
                sliderGrabColor = Color(0xFF00F0FF),
                accentGlow = Color(0xFF00F0FF),
                windowRounding = 10f,
                frameRounding = 6f
            )
            ThemePreset.CRIMSON_SKYMODS -> ImGuiThemeData(
                preset = preset,
                windowBg = Color(0xF0150D0E),
                childBg = Color(0xF0201113),
                headerBg = Color(0xFFE11D48),
                headerHovered = Color(0xFFF43F5E),
                headerActive = Color(0xFFBE123C),
                buttonBg = Color(0xFFBE123C),
                buttonHovered = Color(0xFFE11D48),
                buttonActive = Color(0xFF9F1239),
                frameBg = Color(0xFF281316),
                frameBgHovered = Color(0xFF38181D),
                frameBgActive = Color(0xFF4C1D24),
                borderColor = Color(0xFFFF2A54),
                checkMarkColor = Color(0xFFFF4D6D),
                sliderGrabColor = Color(0xFFFF2A54),
                accentGlow = Color(0xFFFF2A54),
                windowRounding = 8f,
                frameRounding = 5f
            )
            ThemePreset.EMERALD_MATRIX -> ImGuiThemeData(
                preset = preset,
                windowBg = Color(0xF00A140F),
                childBg = Color(0xF00F1E16),
                headerBg = Color(0xFF059669),
                headerHovered = Color(0xFF10B981),
                headerActive = Color(0xFF047857),
                buttonBg = Color(0xFF047857),
                buttonHovered = Color(0xFF059669),
                buttonActive = Color(0xFF065F46),
                frameBg = Color(0xFF132A1F),
                frameBgHovered = Color(0xFF1B3B2B),
                frameBgActive = Color(0xFF244F3A),
                borderColor = Color(0xFF00FF66),
                checkMarkColor = Color(0xFF00FF66),
                sliderGrabColor = Color(0xFF00FF66),
                accentGlow = Color(0xFF00FF66),
                windowRounding = 4f,
                frameRounding = 3f
            )
            ThemePreset.AZURE_GLACIER -> ImGuiThemeData(
                preset = preset,
                windowBg = Color(0xF00B1526),
                childBg = Color(0xF00F1F38),
                headerBg = Color(0xFF0284C7),
                headerHovered = Color(0xFF0EA5E9),
                headerActive = Color(0xFF0369A1),
                buttonBg = Color(0xFF0369A1),
                buttonHovered = Color(0xFF0284C7),
                buttonActive = Color(0xFF075985),
                frameBg = Color(0xFF15294A),
                frameBgHovered = Color(0xFF1C3763),
                frameBgActive = Color(0xFF23467D),
                borderColor = Color(0xFF38BDF8),
                checkMarkColor = Color(0xFF38BDF8),
                sliderGrabColor = Color(0xFF38BDF8),
                accentGlow = Color(0xFF38BDF8),
                windowRounding = 12f,
                frameRounding = 8f
            )
            ThemePreset.DRACULA_PURPLE -> ImGuiThemeData(
                preset = preset,
                windowBg = Color(0xF0181424),
                childBg = Color(0xF0221B33),
                headerBg = Color(0xFF9333EA),
                headerHovered = Color(0xFFA855F7),
                headerActive = Color(0xFF7E22CE),
                buttonBg = Color(0xFF7E22CE),
                buttonHovered = Color(0xFF9333EA),
                buttonActive = Color(0xFF6B21A8),
                frameBg = Color(0xFF2B2240),
                frameBgHovered = Color(0xFF372C52),
                frameBgActive = Color(0xFF453666),
                borderColor = Color(0xFFC084FC),
                checkMarkColor = Color(0xFFF472B6),
                sliderGrabColor = Color(0xFFC084FC),
                accentGlow = Color(0xFFF472B6),
                windowRounding = 10f,
                frameRounding = 6f
            )
            ThemePreset.GOLD_VIP -> ImGuiThemeData(
                preset = preset,
                windowBg = Color(0xF01A160A),
                childBg = Color(0xF026200F),
                headerBg = Color(0xFFD97706),
                headerHovered = Color(0xFFF59E0B),
                headerActive = Color(0xFFB45309),
                buttonBg = Color(0xFFB45309),
                buttonHovered = Color(0xFFD97706),
                buttonActive = Color(0xFF92400E),
                frameBg = Color(0xFF332B14),
                frameBgHovered = Color(0xFF473C1C),
                frameBgActive = Color(0xFF5C4E24),
                borderColor = Color(0xFFFFB800),
                checkMarkColor = Color(0xFFFFD700),
                sliderGrabColor = Color(0xFFFFB800),
                accentGlow = Color(0xFFFFD700),
                windowRounding = 6f,
                frameRounding = 4f
            )
            ThemePreset.MINIMAL_DARK -> ImGuiThemeData(
                preset = preset,
                windowBg = Color(0xF00A0B0E),
                childBg = Color(0xF0121318),
                headerBg = Color(0xFF27272A),
                headerHovered = Color(0xFF3F3F46),
                headerActive = Color(0xFF18181B),
                buttonBg = Color(0xFF27272A),
                buttonHovered = Color(0xFF3F3F46),
                buttonActive = Color(0xFF18181B),
                frameBg = Color(0xFF18181B),
                frameBgHovered = Color(0xFF27272A),
                frameBgActive = Color(0xFF3F3F46),
                borderColor = Color(0xFF52525B),
                checkMarkColor = Color(0xFFE4E4E7),
                sliderGrabColor = Color(0xFFA1A1AA),
                accentGlow = Color(0xFFFFFFFF),
                windowRounding = 6f,
                frameRounding = 4f
            )
        }
        _theme.value = newTheme
    }

    fun applyPresetConfig(presetName: String) {
        when (presetName) {
            "Legit Safe" -> {
                _esp.value = _esp.value.copy(
                    enabled = true,
                    boxType = BoxType.BOX_CORNER,
                    linePos = LinePos.NONE,
                    drawSkeleton = false,
                    drawHeadCircle = true,
                    drawHealthBar = true,
                    drawPlayerName = true,
                    drawDistance = true,
                    drawFovCircle = true,
                    fovRadius = 60f,
                    drawRadar = true
                )
                _aimbot.value = _aimbot.value.copy(
                    enabled = true,
                    targetBone = AimBone.CHEST,
                    aimType = AimType.TOUCH_SIMULATION,
                    smooth = 12.0f,
                    fov = 45f,
                    triggerBot = false,
                    recoilCompensation = true,
                    ignoreKnocked = true,
                    ignoreBots = true
                )
                _memory.value = _memory.value.copy(
                    godMode = false,
                    unlimitedAmmo = false,
                    speedHack = false,
                    noRecoil = false,
                    antiBanActive = true
                )
                applyThemePreset(ThemePreset.AZURE_GLACIER)
            }
            "Full HvH / Rage" -> {
                _esp.value = _esp.value.copy(
                    enabled = true,
                    boxType = BoxType.BOX_3D,
                    linePos = LinePos.BOTTOM,
                    drawSkeleton = true,
                    drawHeadCircle = true,
                    drawHealthBar = true,
                    drawArmorBar = true,
                    drawPlayerName = true,
                    drawDistance = true,
                    drawWeaponName = true,
                    drawFovCircle = true,
                    fovRadius = 180f,
                    drawRadar = true
                )
                _aimbot.value = _aimbot.value.copy(
                    enabled = true,
                    targetBone = AimBone.HEAD,
                    aimType = AimType.SILENT_AIM,
                    smooth = 1.0f,
                    fov = 180f,
                    triggerBot = true,
                    recoilCompensation = true,
                    ignoreKnocked = false,
                    ignoreBots = false
                )
                _memory.value = _memory.value.copy(
                    godMode = true,
                    unlimitedAmmo = true,
                    speedHack = true,
                    speedMultiplier = 2.5f,
                    noRecoil = true,
                    antiBanActive = true
                )
                applyThemePreset(ThemePreset.CRIMSON_SKYMODS)
            }
            "SkyMods VIP Signature" -> {
                _esp.value = _esp.value.copy(
                    enabled = true,
                    boxType = BoxType.BOX_CORNER,
                    linePos = LinePos.CENTER,
                    drawSkeleton = true,
                    drawHeadCircle = true,
                    drawHealthBar = true,
                    drawArmorBar = true,
                    drawPlayerName = true,
                    drawDistance = true,
                    drawWeaponName = true,
                    drawFovCircle = true,
                    fovRadius = 120f,
                    drawRadar = true
                )
                _aimbot.value = _aimbot.value.copy(
                    enabled = true,
                    targetBone = AimBone.HEAD,
                    aimType = AimType.TOUCH_SIMULATION,
                    smooth = 4.5f,
                    fov = 90f,
                    triggerBot = false,
                    recoilCompensation = true,
                    ignoreKnocked = true,
                    ignoreBots = false
                )
                _memory.value = _memory.value.copy(
                    godMode = false,
                    unlimitedAmmo = true,
                    speedHack = false,
                    noRecoil = true,
                    antiBanActive = true
                )
                applyThemePreset(ThemePreset.CYBERPUNK_VIOLET)
            }
        }
        Toast.makeText(getApplication(), "Preset '$presetName' Applied!", Toast.LENGTH_SHORT).show()
    }

    fun spawnDummyBot() {
        val newId = (_targets.value.maxOfOrNull { it.id } ?: 0) + 1
        val weapons = listOf("M416", "AKM", "AWM", "Groza", "Vector", "DP-28")
        val names = listOf("CyberNinja", "ShadowHunter", "AceKiller", "NovaPro", "SkySniper", "Viper_007")
        val bot = DummyTarget(
            id = newId,
            posX = 200f + Random.nextFloat() * 600f,
            posY = 300f + Random.nextFloat() * 500f,
            distanceMeters = 15f + Random.nextFloat() * 90f,
            health = 100f,
            armor = 100f,
            name = names.random(),
            weapon = weapons.random(),
            isKnocked = false,
            isBot = Random.nextBoolean(),
            teamId = Random.nextInt(1, 8),
            velocityX = (Random.nextFloat() - 0.5f) * 1.5f,
            velocityY = (Random.nextFloat() - 0.5f) * 1.5f
        )
        _targets.update { it + bot }
        Toast.makeText(getApplication(), "Spawned Bot #${bot.id} (${bot.name})", Toast.LENGTH_SHORT).show()
    }

    fun damageTarget(id: Int, amount: Float = 35f) {
        _targets.update { list ->
            list.map {
                if (it.id == id) {
                    val newHp = (it.health - amount).coerceAtLeast(0f)
                    it.copy(
                        health = newHp,
                        isKnocked = if (newHp <= 0f) true else it.isKnocked
                    )
                } else it
            }
        }
    }

    fun copyCodeToClipboard(codeText: String, label: String = "C++ Code") {
        val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, codeText)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(getApplication(), "$label copied to clipboard! Ready to paste into your C++ project.", Toast.LENGTH_LONG).show()
    }

    fun getCppCodeForCurrentFile(): String {
        return when (_activeStudioFile.value) {
            "main.cpp" -> CppGenerator.generateMainCpp(_theme.value, _esp.value, _aimbot.value, _memory.value)
            "Menu.h" -> CppGenerator.generateMenuH(_theme.value, _esp.value, _aimbot.value, _memory.value)
            "Menu.cpp" -> CppGenerator.generateMenuCpp(_theme.value, _esp.value, _aimbot.value, _memory.value)
            "ESP.cpp" -> CppGenerator.generateEspCpp(_theme.value, _esp.value)
            "Hooks.cpp" -> CppGenerator.generateHooksCpp()
            "Memory.h" -> CppGenerator.generateMemoryH()
            else -> "// Unknown file"
        }
    }
}
