package com.example.model

import androidx.compose.ui.graphics.Color

enum class BoxType(val label: String) {
    NONE("None"),
    BOX_2D("2D Full Box"),
    BOX_CORNER("Corner Box"),
    BOX_3D("3D Wireframe Box")
}

enum class LinePos(val label: String) {
    NONE("None"),
    TOP("Top Screen"),
    CENTER("Crosshair Center"),
    BOTTOM("Bottom Screen")
}

enum class AimBone(val label: String) {
    HEAD("Head"),
    NECK("Neck"),
    CHEST("Chest"),
    PELVIS("Pelvis")
}

enum class AimType(val label: String) {
    TOUCH_SIMULATION("Touch Simulation (Safe)"),
    MEMORY_HOOK("Direct Memory Aim (Fast)"),
    SILENT_AIM("Silent Bullet Aim (HvH)")
}

enum class ChamsShader(val label: String) {
    NONE("None"),
    WIREFRAME("Wireframe Neon"),
    GLOW_OUTLINE("Glow Outline"),
    SOLID_COLOR("Solid Color"),
    PULSE_HOLOGRAM("Pulse Hologram")
}

enum class ThemePreset(val displayName: String) {
    CYBERPUNK_VIOLET("Cyberpunk Violet Neon"),
    CRIMSON_SKYMODS("Crimson Blood (SkyMods)"),
    EMERALD_MATRIX("Emerald Matrix Hacker"),
    AZURE_GLACIER("Azure Glacier Blue"),
    DRACULA_PURPLE("Dracula Velvet"),
    GOLD_VIP("Gold Luxury VIP"),
    MINIMAL_DARK("Clean Minimal Dark")
}

data class ImGuiThemeData(
    val preset: ThemePreset = ThemePreset.CYBERPUNK_VIOLET,
    val windowBg: Color = Color(0xF012131C),
    val childBg: Color = Color(0xF0181A26),
    val headerBg: Color = Color(0xFF7C3AED),
    val headerHovered: Color = Color(0xFF9055FF),
    val headerActive: Color = Color(0xFF6D28D9),
    val buttonBg: Color = Color(0xFF6D28D9),
    val buttonHovered: Color = Color(0xFF7C3AED),
    val buttonActive: Color = Color(0xFF5B21B6),
    val frameBg: Color = Color(0xFF1E2130),
    val frameBgHovered: Color = Color(0xFF282C40),
    val frameBgActive: Color = Color(0xFF333852),
    val borderColor: Color = Color(0xFF8B5CF6),
    val checkMarkColor: Color = Color(0xFF00F0FF),
    val sliderGrabColor: Color = Color(0xFF00F0FF),
    val textPrimary: Color = Color(0xFFFFFFFF),
    val textSecondary: Color = Color(0xFF94A3B8),
    val accentGlow: Color = Color(0xFF00F0FF),
    val windowRounding: Float = 10f,
    val frameRounding: Float = 6f,
    val grabRounding: Float = 6f,
    val windowBorderSize: Float = 1.5f,
    val alpha: Float = 0.95f,
    val rainbowBorder: Boolean = false,
    val particleBackdrop: Boolean = true
)

data class EspSettings(
    val enabled: Boolean = true,
    val boxType: BoxType = BoxType.BOX_CORNER,
    val boxColor: Color = Color(0xFF00F0FF),
    val linePos: LinePos = LinePos.BOTTOM,
    val lineColor: Color = Color(0xFFFF007F),
    val drawSkeleton: Boolean = true,
    val skeletonColor: Color = Color(0xFFFFFFFF),
    val drawHeadCircle: Boolean = true,
    val headColor: Color = Color(0xFFFF2A54),
    val drawHealthBar: Boolean = true,
    val healthGradient: Boolean = true,
    val drawArmorBar: Boolean = true,
    val drawPlayerName: Boolean = true,
    val drawDistance: Boolean = true,
    val drawWeaponName: Boolean = true,
    val drawLineOfSight: Boolean = true,
    val drawFovCircle: Boolean = true,
    val fovRadius: Float = 120f,
    val fovColor: Color = Color(0x668B5CF6),
    val rainbowFov: Boolean = false,
    val fovThickness: Float = 2f,
    val drawRadar: Boolean = true,
    val radarScale: Float = 1.0f,
    val radarPosX: Float = 40f,
    val radarPosY: Float = 80f,
    val chamsShader: ChamsShader = ChamsShader.GLOW_OUTLINE,
    val chamsColor: Color = Color(0xFF7C3AED)
)

data class AimbotSettings(
    val enabled: Boolean = true,
    val targetBone: AimBone = AimBone.HEAD,
    val aimType: AimType = AimType.TOUCH_SIMULATION,
    val smooth: Float = 4.5f,
    val fov: Float = 90f,
    val triggerBot: Boolean = false,
    val recoilCompensation: Boolean = true,
    val bulletPrediction: Boolean = true,
    val ignoreKnocked: Boolean = true,
    val ignoreBots: Boolean = false,
    val maxAimDistance: Float = 250f
)

data class MemoryModsSettings(
    val godMode: Boolean = false,
    val unlimitedAmmo: Boolean = true,
    val speedHack: Boolean = false,
    val speedMultiplier: Float = 1.5f,
    val jumpHeight: Float = 1.0f,
    val highDamage: Boolean = false,
    val wallHackChams: Boolean = true,
    val noRecoil: Boolean = true,
    val wideViewFov: Float = 90f,
    val antiBanActive: Boolean = true,
    val bypassMemoryScan: Boolean = true,
    val spoofDeviceFingerprint: Boolean = true
)

data class DummyTarget(
    val id: Int,
    var posX: Float,
    var posY: Float,
    var distanceMeters: Float,
    var health: Float,
    var armor: Float,
    var name: String,
    var weapon: String,
    var isKnocked: Boolean = false,
    var isBot: Boolean = false,
    var teamId: Int = 1,
    var lookAngle: Float = 0f,
    var velocityX: Float = 0f,
    var velocityY: Float = 0f
)

data class ConfigPreset(
    val name: String,
    val description: String,
    val esp: EspSettings,
    val aimbot: AimbotSettings,
    val memory: MemoryModsSettings,
    val theme: ImGuiThemeData
)
