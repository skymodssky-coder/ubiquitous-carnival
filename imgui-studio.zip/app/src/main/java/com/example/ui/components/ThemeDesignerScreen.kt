package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CppGenerator
import com.example.model.ThemePreset
import com.example.viewmodel.ImGuiViewModel

@Composable
fun ThemeDesignerScreen(
    viewModel: ImGuiViewModel,
    modifier: Modifier = Modifier
) {
    val theme by viewModel.theme.collectAsState()
    val esp by viewModel.esp.collectAsState()
    val aimbot by viewModel.aimbot.collectAsState()
    val memory by viewModel.memory.collectAsState()

    var dummyCheck by remember { mutableStateOf(true) }
    var dummySlider by remember { mutableStateOf(75f) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0C13))
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
            .testTag("theme_designer_screen")
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Palette,
                contentDescription = null,
                tint = Color(0xFF00F0FF),
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "ImGui Theme & Visual Architect",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Live Theme Customizer with real-time C++ struct compilation",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )
            }
        }

        // Live Preview Card
        Card(
            colors = CardDefaults.cardColors(containerColor = theme.windowBg.copy(alpha = theme.alpha)),
            shape = RoundedCornerShape(theme.windowRounding.dp),
            border = androidx.compose.foundation.BorderStroke(theme.windowBorderSize.dp, theme.borderColor),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Mock Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(theme.frameRounding.dp))
                        .background(theme.headerBg)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "⚡ ImGui Window Preview",
                        color = theme.textPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = theme.preset.displayName,
                        color = theme.accentGlow,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))

                // Mock Controls
                ImGuiCheckbox(
                    label = "Active Glowing Checkbox",
                    checked = dummyCheck,
                    onCheckedChange = { dummyCheck = it },
                    theme = theme
                )
                ImGuiSlider(
                    label = "Aimbot Smoothness",
                    value = dummySlider,
                    onValueChange = { dummySlider = it },
                    valueRange = 0f..100f,
                    theme = theme,
                    unit = "%"
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ImGuiButton(
                        text = "Primary Button",
                        onClick = {},
                        theme = theme,
                        modifier = Modifier.weight(1f),
                        isPrimary = true
                    )
                    ImGuiButton(
                        text = "Secondary",
                        onClick = {},
                        theme = theme,
                        modifier = Modifier.weight(1f),
                        isPrimary = false
                    )
                }
            }
        }

        // Theme Presets Selector
        ImGuiSectionHeader(title = "Select Style Preset", theme = theme)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ThemePreset.values().take(4).forEach { p ->
                val isSel = theme.preset == p
                Surface(
                    color = if (isSel) theme.buttonBg else Color(0xFF141824),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) theme.accentGlow else Color(0xFF232A3E)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.applyThemePreset(p) }
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp)
                    ) {
                        Text(
                            text = p.name.split("_").last(),
                            color = if (isSel) Color.White else Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ThemePreset.values().drop(4).forEach { p ->
                val isSel = theme.preset == p
                Surface(
                    color = if (isSel) theme.buttonBg else Color(0xFF141824),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) theme.accentGlow else Color(0xFF232A3E)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.applyThemePreset(p) }
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp)
                    ) {
                        Text(
                            text = p.name.split("_").last(),
                            color = if (isSel) Color.White else Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Color Customization
        ImGuiSectionHeader(title = "ImGui Color Palette", theme = theme)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111420)),
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E2436)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                ImGuiColorField(
                    label = "Window Background (ImGuiCol_WindowBg)",
                    color = theme.windowBg,
                    onColorChange = { viewModel.updateTheme { t -> t.copy(windowBg = it) } },
                    theme = theme
                )
                ImGuiColorField(
                    label = "Header & Title (ImGuiCol_Header)",
                    color = theme.headerBg,
                    onColorChange = { viewModel.updateTheme { t -> t.copy(headerBg = it, headerHovered = it) } },
                    theme = theme
                )
                ImGuiColorField(
                    label = "Buttons (ImGuiCol_Button)",
                    color = theme.buttonBg,
                    onColorChange = { viewModel.updateTheme { t -> t.copy(buttonBg = it) } },
                    theme = theme
                )
                ImGuiColorField(
                    label = "Frame Background (ImGuiCol_FrameBg)",
                    color = theme.frameBg,
                    onColorChange = { viewModel.updateTheme { t -> t.copy(frameBg = it) } },
                    theme = theme
                )
                ImGuiColorField(
                    label = "Borders (ImGuiCol_Border)",
                    color = theme.borderColor,
                    onColorChange = { viewModel.updateTheme { t -> t.copy(borderColor = it) } },
                    theme = theme
                )
                ImGuiColorField(
                    label = "Checkmark & Accent (ImGuiCol_CheckMark)",
                    color = theme.checkMarkColor,
                    onColorChange = { viewModel.updateTheme { t -> t.copy(checkMarkColor = it, accentGlow = it) } },
                    theme = theme
                )
                ImGuiColorField(
                    label = "Slider Grab (ImGuiCol_SliderGrab)",
                    color = theme.sliderGrabColor,
                    onColorChange = { viewModel.updateTheme { t -> t.copy(sliderGrabColor = it) } },
                    theme = theme
                )
            }
        }

        // Rounding & Geometry
        ImGuiSectionHeader(title = "Rounding & Geometry", theme = theme)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111420)),
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E2436)),
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                ImGuiSlider(
                    label = "Window Rounding",
                    value = theme.windowRounding,
                    onValueChange = { viewModel.updateTheme { t -> t.copy(windowRounding = it) } },
                    valueRange = 0f..20f,
                    valueFormat = "%.0f",
                    unit = "px",
                    theme = theme
                )
                ImGuiSlider(
                    label = "Frame Rounding",
                    value = theme.frameRounding,
                    onValueChange = { viewModel.updateTheme { t -> t.copy(frameRounding = it) } },
                    valueRange = 0f..15f,
                    valueFormat = "%.0f",
                    unit = "px",
                    theme = theme
                )
                ImGuiSlider(
                    label = "Grab Rounding",
                    value = theme.grabRounding,
                    onValueChange = { viewModel.updateTheme { t -> t.copy(grabRounding = it) } },
                    valueRange = 0f..15f,
                    valueFormat = "%.0f",
                    unit = "px",
                    theme = theme
                )
                ImGuiSlider(
                    label = "Border Thickness",
                    value = theme.windowBorderSize,
                    onValueChange = { viewModel.updateTheme { t -> t.copy(windowBorderSize = it) } },
                    valueRange = 0.5f..4.0f,
                    valueFormat = "%.1f",
                    unit = "px",
                    theme = theme
                )
                ImGuiSlider(
                    label = "Window Transparency (Alpha)",
                    value = theme.alpha,
                    onValueChange = { viewModel.updateTheme { t -> t.copy(alpha = it) } },
                    valueRange = 0.3f..1.0f,
                    valueFormat = "%.2f",
                    theme = theme
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Copy C++ Theme Function Button
        Button(
            onClick = {
                val cppCode = CppGenerator.generateMainCpp(theme, esp, aimbot, memory)
                viewModel.copyCodeToClipboard(cppCode, "SetupImGuiTheme C++")
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = theme.buttonBg,
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Copy SetupImGuiTheme() C++ Code",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
